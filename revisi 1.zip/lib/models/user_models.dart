class UserModel {
  final String nim;
  final String password;

  UserModel({required this.nim, required this.password});
}
