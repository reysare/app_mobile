class AuthService {
  bool login(String nim, String password) {
    // Dummy auth logic
    return nim == '123' && password == 'password';
  }
}
